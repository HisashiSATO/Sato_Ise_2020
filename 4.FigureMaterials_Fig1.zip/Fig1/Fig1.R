#Drawing code for Figure 1 in the Sato & Ise (2020)
#Dr. Hisashi SATO (JAMSTEC) 2020 May 1

#____________________ Parameter Settings ____________________
   #Resoution of map grid
   Resol <- 0.5
   
   #Map Area for drawing (@ coordinate system of the SEIb-DGVM)
   LatNoStart    <-     10 #North edge
   LatNoEnd      <-    300 #South edge
   LonNoStart    <-      1 #West edge
   LonNoEnd      <-    720 #East edge
   
   #Fixed Parameters
   LatNoMax <- 360 #Maximu number for Latitude No.
   LonNoMax <- 720 #Maximu number for Longitude No.
   VegNoMax <-  15 #Maximu number for Vegetation No.
   
   #Definitions of Vegetation Names
   VegName  <- array("", dim=c(VegNoMax))
   VegName[ 1] <- "Tropical Evergreen Forest"
   VegName[ 2] <- "Tropical Deciduous Forest / Woodland"
   VegName[ 3] <- "Temperate Broadleaf Evergreen Forest"
   VegName[ 4] <- "Temperate Needleleaf Evergreen Forest"
   VegName[ 5] <- "Temperate Deciduous Forest"
   VegName[ 6] <- "Boreal Evergreen Forest"
   VegName[ 7] <- "Boreal Deciduous Forest"
   VegName[ 8] <- "Evergreen / Deciduous Mixed Forest"
   VegName[ 9] <- "Savanna"
   VegName[10] <- "Grassland / Steppe"
   VegName[11] <- "Dense Shrubland"
   VegName[12] <- "Open Shrubland"
   VegName[13] <- "Tundra"
   VegName[14] <- "Desert"
   VegName[15] <- "Polar Desert / Rock / Ice"
   
   #Assignement of color for each Vegetation
   col <- c(    
   "white"               , #0, Water Bodies
   "red"                 , #1, Tropical Evergreen Forest/Woodland
   "hotpink3"            , #2, Tropical Deciduous Forest/Woodland
   "darkgreen"           , #3, Temperate Broadleaf Evergreen Forest/ Woodland
   "green3"              , #4, Temperate Needleleaf Evergreen Forest/Woodland
   "darkseagreen1"       , #5, Temperate Deciduous Forest/Woodland
   "darkblue"            , #6, Boreal Evergreen Forest/Woodland
   "royalblue"           , #7, Boreal Deciduous Forest/Woodland
   "skyblue"             , #8, Evergreen/Deciduous Mixed Forest
   "lightpink"           , #9, Savanna
   "yellow"              , #10, Grassland/Steppe
   "burlywood4"          , #11, Dense Shrubland
   "Goldenrod"           , #12, Open Shrubland
   "darkviolet"          , #13, Tundra
   "gray"                , #14, Desert
   "LightSlateGray"      , #15, Polar Desert/Rock/Ice
   "black"               ) #16, No Data over Land
   
#____________________ Preparation ____________________
   library(stringr) #a library string manupulation
   library(maps)    #a library for mapping
   
   #Grid sizes for Vertical and Horizontal axis
   LatMax <- 180 / Resol #Latitudinal Grid Size
   LonMax <- 360 / Resol #Longitudinal Grid Size
   
   #Reference number for latitude
   LatNo1    <-    LatMax-LatNoEnd+1   #Southern Edge
   LatNo2    <-    LatMax-LatNoStart+1 #Northern Edge
   
   #y: Latitude (From south to north, Arrays have to be sscending order in R)
   y <- array(0.0, dim=c(LatMax))                     
   for(i in 1:LatMax)  y[i] <- i*Resol-(90 + Resol/2) 
   
   #x: Longitude (From west to east)
   x <- array(0.0, dim=c(LonMax))                      
   for(i in 1:LonMax)  x[i] <- i*Resol-(180 + Resol/2) 
   
   #Array preparation for reading data
   reader1 <- array(0, dim=c(LonNoMax,LatNoMax))	#�Ǎ��f�[�^�ۑ��p�z��
   reader2 <- array(0, dim=c(LonNoMax,LatNoMax))	#�Ǎ��f�[�^�ۑ��p�z��
   reader3 <- array(0, dim=c(LonNoMax,LatNoMax))	#�Ǎ��f�[�^�ۑ��p�z��
   d1      <- array(0, dim=c(LonNoMax,LatNoMax))	#�Ǎ��f�[�^�ۑ��p�z��
   d2      <- array(0, dim=c(LonNoMax,LatNoMax))	#�Ǎ��f�[�^�ۑ��p�z��
   d3      <- array(0, dim=c(LonNoMax,LatNoMax))	#�Ǎ��f�[�^�ۑ��p�z��
   d_empty <- array(-999, dim=c(LonNoMax,LatNoMax))
   
#____________________ Data read & its conversion  ____________________
   reader1 <- read.csv('potential_veg_hd.csv'                      , header=F) 
   reader2 <- read.csv('VegNo_MainSim_AMean_CRU.csv', header=F)
   reader3 <- read.csv('VegNo_MainSim_MMean_CRU.csv' , header=F)
   
   #�p�ӂ����ϐ��ɓ�k�Ђ�����Ԃ��Ċi�[
   for (lat in 1:LatMax) {
   for (lon in 1:LonMax) {
      d1 [lon,LatMax-lat+1] <- reader1[lat,lon] 
      d2 [lon,LatMax-lat+1] <- reader2[lat,lon] 
      d3 [lon,LatMax-lat+1] <- reader3[lat,lon] 
   }}
   
   #���ݐA���n�}��16��(No Data over Land)�̃O���b�h�́ASim�l�f�[�^��16�Ԃɋ����u��
   for (lat in 1:300) {        
      for (lon in 1:720) {        
         if (d1[lon,lat]==16) {d2[lon,lat]<-16}
         if (d1[lon,lat]==16) {d3[lon,lat]<-16}
      }
   }
   
#____________________ Map Drawing  ____________________
   #�F�̕����_�ƃJ���[�p���b�g����
   br  <- c(-1,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16) #�l�̕����_(�l�̕����_=�F�̐�+1)
   
   #�f�o�C�X�h���C�o�J��
   png('Fig1.png', width=2300, height=1150) 
   par(mfrow = c(2,2)            )  #���s�E����ɕ���
   par(oma   = c(5,  5,  5,  5) )  #���E���E��E�E�̏��ŗ]����ݒ�
   par(ps    = 30                )  #�����|�C���g�T�C�Y
   par(lwd   = 1.8               )  #���̑���
   par(mar   = c(0, 1, 1, 0)     )  #�X�̐}�̗]��(�P��:line)(�f�t�H���g:c(5,4,4,2)
   par(mgp   = c(4, 2, 0)        )  #�f�t�H���g��c(3, 1, 0)
�@                                  #mgp[1]: �����烉�x���܂ł̃}�[�W��
�@                                  #mgp[2]: ������ڐ��܂ł̃}�[�W��
�@                                  #mgp[3]: �����玲���܂ł̃}�[�W��
   
   
   #Map 1
   image(x[LonNoStart:LonNoEnd], y[LatNo1:LatNo2], d1[LonNoStart:LonNoEnd, LatNo1:LatNo2], 
   breaks=br, col=col, xlab='', ylab='', axes = FALSE)
   map(add=T)                                                              #Overlay Map
   text(-150, -30, pos=1, cex=3, "a") 
   box()
   axis(side=4, at=seq( -50,  75, by=25), cex=0.5 )  #axis for latitude
   
   #Ledgend Drawing
   image(x[LonNoStart:LonNoEnd], y[LatNo1:LatNo2], d_empty[LonNoStart:LonNoEnd, LatNo1:LatNo2], 
   breaks=br, col=col, xlab='', ylab='', axes = FALSE)

   par( adj=0   )
   
   y_start <-   50
   y_width <-   13.0
   
   for (j in c(2:9)) {
      polygon( c(-155,-155,-140,-140), c(y_start, y_start+y_width, y_start+y_width, y_start), , col=col[j])
         if (j== 2) text(-135, y_start+y_width*0.5, cex=1.2, "Tropical Evergreen forest")
         if (j== 3) text(-135, y_start+y_width*0.5, cex=1.2, "Tropical Deciduous Forest / Woodland")
         if (j== 4) text(-135, y_start+y_width*0.5, cex=1.2, "Temperate Broadleaf Evergreen Forest")
         if (j== 5) text(-135, y_start+y_width*0.5, cex=1.2, "Temperate Needleleaf Evergreen Forest")
         if (j== 6) text(-135, y_start+y_width*0.5, cex=1.2, "Temperate Deciduous Forest")
         if (j== 7) text(-135, y_start+y_width*0.5, cex=1.2, "Boreal Evergreen Forest")
         if (j== 8) text(-135, y_start+y_width*0.5, cex=1.2, "Boreal Deciduous Forest")
         if (j== 9) text(-135, y_start+y_width*0.5, cex=1.2, "Evergreen / Deciduous Mixed Forest")
      y_start <- y_start-y_width
   }
         
   y_start <-   50
   for (j in c(10:17)) {
      polygon( c(55,55,70,70), c(y_start, y_start+y_width, y_start+y_width, y_start), , col=col[j])
         if (j==10) text(75, y_start+y_width*0.5, cex=1.2, "Savanna")
         if (j==11) text(75, y_start+y_width*0.5, cex=1.2, "Grassland / Steppe")
         if (j==12) text(75, y_start+y_width*0.5, cex=1.2, "Dense Shrubland")
         if (j==13) text(75, y_start+y_width*0.5, cex=1.2, "Open Shrubland")
         if (j==14) text(75, y_start+y_width*0.5, cex=1.2, "Tundra")
         if (j==15) text(75, y_start+y_width*0.5, cex=1.2, "Desert")
         if (j==16) text(75, y_start+y_width*0.5, cex=1.2, "Polar Desert / Rock / Ice")
         if (j==17) text(75, y_start+y_width*0.5, cex=1.2, "No Data over Land")
      y_start <- y_start-y_width
   }
   
   #Map 2
   image(x[LonNoStart:LonNoEnd], y[LatNo1:LatNo2], d2[LonNoStart:LonNoEnd, LatNo1:LatNo2], 
   breaks=br, col=col, xlab='', ylab='', axes = FALSE)
   map(add=T)
   text(-150, -30, pos=1, cex=3, "b") 
   box()
   axis(side=1, at=seq(-150, 150, by=30), cex=0.5 )  #�o�x��
   
   #Map 3
   image(x[LonNoStart:LonNoEnd], y[LatNo1:LatNo2], d3[LonNoStart:LonNoEnd, LatNo1:LatNo2],
   breaks=br, col=col, xlab='', ylab='', axes = FALSE)
   map(add=T)
   text(-150, -30, pos=1, cex=3, "c") 
   box()
   axis(side=1, at=seq(-150, 150, by=30), cex=0.5 )  #�o�x��
   axis(side=4, at=seq( -50,  75, by=25), cex=0.5 )  #�ܓx��
   
   #�f�o�C�X�h���C�o����
   dev.off()
   
